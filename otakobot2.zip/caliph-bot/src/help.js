const help = (prefix, pushname) => {
	return `✪═⟪ COMUNIDADE OTAKU BOT MENU ⟫═✪

*AUTHOR : COMUNIDADE OTAKU*
*BOT TYPE : TERMUX*

╔════════════════════
║ Ola otaku *${pushname}*
╠════════════════════
║╭──❉ *INFO* ❉──
║│1. ${prefix}info
║│2. ${prefix}bugreport <lapor bug>
║│3. ${prefix}runtime
║│4. ${prefix}join <linkgroup>
║╰───────────
║╭──❉ *Menu do grupo* ❉──
║│1. ${prefix}clone
║│2. ${prefix}promote <@tagmember>
║│3. ${prefix}demote <@tagadmin>
║│4. ${prefix}tagall <1 atau 2 atau 3>
║│5. ${prefix}simih <0 atau 1>
║│6. ${prefix}group <open atau close>
║│8. ${prefix}setdesc <teks>
║│9. ${prefix}setpp 
║│10. ${prefix}setname <teks>
║│11. ${prefix}kick <@tagmember>
║│12. ${prefix}linkgroup
║╰───────────
║╭──❉ *MEDIA* ❉──
║│1. ${prefix}toimg <reply stiker>
║│2. ${prefix}sticker
║│3. ${prefix}ttp <teks>
║│4. ${prefix}sticker nobg <ERROR>
║│5. ${prefix}tts <kode bahasa> <teks>
║│6. ${prefix}url2img <tipe> <url>
║│7. ${prefix}wait <kirim atau reply foto>
║│8. ${prefix}ocr
║│9. ${prefix}nulis <teks>
║╰───────────
║╭──❉ *OWNER MENU* ❉──
║│1. ${prefix}setprefix <prefix>
║│2. ${prefix}bc <promosi>
║│3. ${prefix}setppbot 
║│4. ${prefix}clone @tagmember
║╰───────────
║╭──❉ *IKLAN* ❉──
║│1. Instagram
║│ @comunidade.de.otaku
║│2. Creator comunidade otaku
║│ https://wa.me/5521998250174
║╰───────────
║╭──❉ *ATENÇAO* ❉──
║│1. _NAO FLODE O BOT_
║│2. _RESPEITAR O ADM_

║╰───────────
╠════════════════════
║  _*COMUNIDADE OTAKU*_
╚════════════════════`
}

exports.help = help
